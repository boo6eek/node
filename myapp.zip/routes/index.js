var express = require('express');
var router = express.Router();

var db = require('../config/db');

var mongoose = require('mongoose');

mongoose.connect(db.url);

var db = mongoose.connection;

var objectId = require('mongodb').ObjectId;


router.post('/add', function (req, res) {
    var comment = {
        date: Date.now(),
        name: req.body.name,
        title: 'asdasd',
        text: req.body.comment
    }

    db.collection('comments').insert(comment, function (err, res) {
        if (err)
            console.log(err);

    })
    db.collection('comments').find().toArray(function (err, docs) {
        console.log(docs);
        res.send(docs);
    })
});

router.get('/',function (req, res) {
    db.collection('comments').find().toArray(function (err, docs) {
        if (err)
            console.log(err);
        console.log(docs);
        res.render('index', {title: 'Коментарии', comments: docs});
    })
});



module.exports = router;
