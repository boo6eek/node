var express = require('express');
var router = express.Router();

var db = require('../config/db');

var mongoose = require('mongoose');

mongoose.connect(db.url);

var db = mongoose.connection;

var objectId = require('mongodb').ObjectId;

var title = 'Comments';


router.get('/',function (req, res) {
    db.collection('comments').find().toArray(function (err, comments) {
        if (err)
            console.log(err);
        //console.log(comments);
        res.render('index', {title: title, comments: comments});
    })
});

router.post('/add', function (req, res) {
    var comment = {
        date: Date.now(),
        name: req.body.name,
        title: 'asdasd',
        text: req.body.comment
    }

    db.collection('comments').insert(comment, function (err, res) {
        if (err)
            console.log(err);

    })
    db.collection('comments').find().toArray(function (err, comments) {
        if (err)
            console.log(err);
        console.log(comments);
        res.render('index', {title: title, comments: comments});
    })
});

module.exports = router;
